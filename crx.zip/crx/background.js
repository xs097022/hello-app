console.log('pbledfcfnijoghpdgapfbbghlofgmfmn');

const Map = {};

const create = async (config) => new Promise(resolve => chrome.app.window.create('1.html', {
    innerBounds: {
        width: Math.ceil(config.w || (720 / window.devicePixelRatio)),
        height:  Math.ceil(config.h || (1280 / window.devicePixelRatio))
    },
    resizable: false,
    frame: 'none'
}, (appWindow) => {
    appWindow.contentWindow.onload = function() {
        const webview = appWindow.contentWindow.document.getElementById('webview');
        webview.addEventListener('permissionrequest', (e) => {
            if (e.permission === 'media') {
                e.request.allow();
            }
        });
        resolve(appWindow);
    };
}));

chrome.runtime.onMessageExternal.addListener(async (request, sender, sendResponse) => {
    const req = request || {};
    const fn = ({
        async create(req) {
            const id = Math.random() * 10000000 >> 0;
            const appWindow = await create(req);
            const webview = appWindow.contentWindow.document.getElementById('webview');
            webview.setZoom(1 / window.devicePixelRatio);
            req.url && (webview.src = req.url);
            Map[id] = appWindow;
            appWindow.onClosed.addListener(() => {
                delete(Map[id]);
            });
            return id;
        },
        close(req) {
            Map[req.id] && Map[req.id].close();
            return 'OK';
        }
    })[req.type]
    sendResponse(fn && await fn(req));
});

//103.31.115.50:15987
//root / 4Ch435@K7i
